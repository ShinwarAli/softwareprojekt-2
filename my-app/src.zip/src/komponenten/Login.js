import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Login.css';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    passwort: ''
  });

  const navigate = useNavigate();

  const handleRedirect = () => {
    navigate('/regester');
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      const result = await response.json();
      if (response.ok) {
        // Store the user ID in localStorage after successful login
        localStorage.setItem('userId', result.userId); // Make sure result.userId contains the correct user ID
        alert('Login erfolgreich!');
        // Redirect to the next page after successful login
        navigate('/steps');
      } else {
        alert('Fehler beim Login: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Fehler beim Login.');
    }
  };

  return (
    <div className="login">
      <main className="login-main">
        <div className="content-containerLogin">
          <div className="ueberschrift">
            <h1>STUDYPLANERMANAGER</h1>
          </div>
          <form className="input-containerLogin" onSubmit={handleSubmit}>
            <label htmlFor="email" className="emailOben">Email:</label>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} placeholder="Geben Sie Ihre Email ein" required />

            <label htmlFor="passwort" className="passwortlOben">Passwort:</label>
            <input type="password" id="passwort" name="passwort" value={formData.passwort} onChange={handleChange} placeholder="Geben Sie Ihr Passwort ein" required />

            <div className="additional-options">
              <div className="remember-me">
                <input type="checkbox" id="rememberMe" name="rememberMe" />
                <label htmlFor="rememberMe">Erinnere mich</label>
              </div>
              <div className="forgot-password">
                <a href="/forgot-password">Passwort vergessen?</a>
              </div>
            </div>

            <div className="button-container">
              <button type="submit" className="anmelden-button">Anmelden</button>
            </div>

            <div className="register-link">
              <p>HAST DU KEIN KONTO? <span onClick={handleRedirect} style={{cursor: 'pointer', color: 'blue', textDecoration: 'underline'}}>HIER REGISTRIEREN</span></p>
            </div>
          </form>
        </div>
        <div className="image-containerlogin">
          <img src={`${process.env.PUBLIC_URL}/regester2.png`} alt="Bildbeschreibung" className="login-image" />
        </div>
      </main>
    </div>
  );
};

export default Login;
