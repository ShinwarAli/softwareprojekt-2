import React, { useEffect, useState } from 'react';
import './Auswahl.css';


const Header = () => {
  const [timetable, setTimetable] = useState([]);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    // Retrieve userId from localStorage or other storage
    const storedUserId = localStorage.getItem('userId'); // Adjust this line based on your actual implementation
    setUserId(storedUserId);

    if (storedUserId) {
      fetch(`http://localhost:3000/api/timetable?userId=${storedUserId}`)
        .then(response => response.json())
        .then(data => setTimetable(data))
        .catch(error => console.error('Error fetching timetable:', error));
    }
  }, []);

  const timeslots = [
    "08:00-09:00",
    "09:00-10:00",
    "10:00-11:00",
    "11:00-12:00",
    "12:00-13:00",
    "13:00-14:00",
    "14:00-15:00",
    "15:00-16:00",
    "16:00-17:00",
    "17:00-18:00",
    "18:00-19:00",
    "19:00-20:00"
  ];

  const days = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag'];

  const renderTableData = () => {
    return timeslots.map((time) => (
      
      <tr key={time}>
        <td className="time-slot">{time}</td>
        {days.map((day) => {
          const entry = timetable.find(
            (item) => item.tag === day && item.zeit === time
          );
          return (
            <td key={day}>
              {entry ? (
                <>
                  <div>{entry.kurs}</div>
                  <div>{entry.prof}</div>
                  <div>{entry.raum}</div>
                </>
              ) : (
                <div className="empty-slot">-</div>
              )}
            </td>
          );
        })}
      </tr>
    ));
  };

  return (
    <main id="mainAuswahl">
      <h1>Timetable</h1>
      <table>
        <thead>
          <tr>
            <th>Time</th>
            {days.map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>{renderTableData()}</tbody>
      </table>
    </main>
  );
};

export default Header;
