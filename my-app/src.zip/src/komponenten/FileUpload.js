import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './FileUpload.css';

const FileUpload = () => {
  const [htmlFilesData, setHtmlFilesData] = useState([]); // Speichert Dateien und deren Inhalte
  const [selectedFile, setSelectedFile] = useState(''); // Aktuell ausgewählte Datei
  const [selectedCourses, setSelectedCourses] = useState({}); // Speichert die ausgewählten Kurse je Datei
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  // Funktion zur Umwandlung von Umlauten und Sonderzeichen
  const replaceSpecialCharacters = (text) => {
    return text
      .replace(/ä/g, 'a')
      .replace(/ö/g, 'o')
      .replace(/ü/g, 'u')
      .replace(/Ä/g, 'A')
      .replace(/Ö/g, 'O')
      .replace(/Ü/g, 'U')
      .replace(/ß/g, 'ss')
      .replace(/[^\x20-\x7E]/g, ''); // Entferne alle nicht-ASCII Zeichen
  };

  // Handle multiple HTML/HTM file selection
  const onHtmlFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files); // Mehrere Dateien
    let fileDataList = [];
  
    selectedFiles.forEach((file) => {
      const fileExtension = file?.name.split('.').pop().toLowerCase();
  
      if (fileExtension !== 'html' && fileExtension !== 'htm') {
        setMessage('Bitte wählen Sie gültige HTML- oder HTM-Dateien aus!');
        return;
      }
  
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const textContent = new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(event.target.result));
          
          // Check for <meta charset="..."> and detect encoding
          const metaCharset = /<meta.*?charset=["']?([^"']+)["']?/i.exec(textContent);
          let encoding = metaCharset ? metaCharset[1].toLowerCase() : 'utf-8';
  
          // If the detected encoding isn't UTF-8, decode again with that encoding
          let decodedContent;
          if (encoding !== 'utf-8') {
            decodedContent = new TextDecoder(encoding, { fatal: false }).decode(new Uint8Array(event.target.result));
          } else {
            decodedContent = textContent;
          }
  
          const parser = new DOMParser();
          const doc = parser.parseFromString(decodedContent, 'text/html');
          const timetableTable = doc.querySelector('table[width="100%"]');
  
          if (!timetableTable) {
            setMessage(`Kein Stundenplan gefunden in der Datei: ${file.name}`);
            return;
          }
  
          const rows = Array.from(timetableTable.getElementsByTagName('tr')).slice(1);
          const timetableData = rows.map((row) => {
            const cells = row.getElementsByTagName('td');
            return {
              Instructor: replaceSpecialCharacters(cells[0]?.textContent?.trim() || ''),
              Course: replaceSpecialCharacters(cells[1]?.textContent?.trim() || ''),
              Day: replaceSpecialCharacters(cells[2]?.textContent?.trim() || ''),
              Time: replaceSpecialCharacters(cells[3]?.textContent?.trim() || ''),
              Room: replaceSpecialCharacters(cells[4]?.textContent?.trim() || ''),
            };
          });
  
          // Speicher das Timetable und den Dateinamen
          fileDataList.push({ fileName: file.name, timetable: timetableData });
  
          // Setze die Dateien-Daten sobald alle Dateien gelesen wurden
          if (fileDataList.length === selectedFiles.length) {
            setHtmlFilesData(fileDataList);
            setSelectedFile(fileDataList[0]?.fileName || ''); // Setze die erste Datei als Standard-Auswahl
          }
        } catch (error) {
          setMessage('Fehler beim Parsen der HTML-Datei!');
        }
      };
      reader.readAsArrayBuffer(file); // Lies die Datei als ArrayBuffer
    });
  };
  

  const onCourseSelect = (fileName, courseName) => {
    setSelectedCourses((prevSelectedCourses) => {
      const fileCourses = prevSelectedCourses[fileName] || [];
      const newSelectedCourses = fileCourses.includes(courseName)
        ? fileCourses.filter((course) => course !== courseName) // Deselektieren
        : [...fileCourses, courseName]; // Auswählen

      return {
        ...prevSelectedCourses,
        [fileName]: newSelectedCourses,
      };
    });
  };

  // Funktion zur Entfernung von Duplikaten basierend auf den Kursdaten
  const removeDuplicateCourses = (timetable) => {
    const uniqueCourses = timetable.filter((value, index, self) =>
      index === self.findIndex((t) => (
        t.Course === value.Course && t.Instructor === value.Instructor
      ))
    );
    return uniqueCourses;
  };

  const onFileUpload = () => {
    if (htmlFilesData.length === 0) {
      setMessage('Bitte wählen Sie mindestens eine HTML/HTM-Datei aus!');
      return;
    }

    const userId = localStorage.getItem('userId');
    if (!userId) {
      setMessage('Benutzer-ID ist nicht verfügbar. Weiterleitung zur Anmeldung...');
      setTimeout(() => {
        navigate('/'); // Redirect to login page after 2 seconds
      }, 2000);
      return;
    }

    // Für jede Datei die ausgewählten Kurse filtern und hochladen
    htmlFilesData.forEach((fileData) => {
      const selectedFileCourses = selectedCourses[fileData.fileName] || [];
      const selectedCoursesData = fileData.timetable.filter(item => selectedFileCourses.includes(item.Course));

      // Ersetze Umlaute in den Kursnamen für das Hochladen
      const formattedCoursesData = selectedCoursesData.map(course => ({
        ...course,
        Course: replaceSpecialCharacters(course.Course), // Umlaute ersetzen
      }));

      const formData = new FormData();
      formData.append(
        'file',
        new Blob([JSON.stringify({ timetable: formattedCoursesData })], { type: 'application/json' })
      );
      formData.append('userId', userId);

      fetch('http://localhost:3000/api/upload', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          setMessage(`Datei "${fileData.fileName}" erfolgreich hochgeladen!`);
          const userChoice = window.confirm('Möchtest du noch eine andere Datei hochladen?');
          if (userChoice) {
            window.location.reload();
          } else {
            navigate('/auswahl');
          }
        })
        .catch((error) => {
          setMessage('Hochladen der Datei fehlgeschlagen!');
          console.error('Fehler beim Hochladen der Datei:', error);
        });
    });
  };

  return (
    <div className="file-upload-container">
      <h2>Datei hochladen</h2>
      <input
        type="file"
        id="htmlFileInput"
        onChange={onHtmlFileChange}
        accept=".html,.htm"
        multiple // Mehrfachauswahl erlauben
      />
      <label htmlFor="htmlFileInput">Wählen Sie HTML/HTM-Dateien</label>

      {/* Menü zur Auswahl der Datei */}
      {htmlFilesData.length > 0 && (
        <div className="file-menu">
          <label htmlFor="fileSelect">Datei auswählen:</label>
          <select
            id="fileSelect"
            value={selectedFile}
            onChange={(e) => setSelectedFile(e.target.value)}
          >
            {htmlFilesData.map((fileData, index) => (
              <option key={index} value={fileData.fileName}>
                {fileData.fileName}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Zeige die Kurse der ausgewählten Datei an */}
      {selectedFile && htmlFilesData.length > 0 && (
        <div className="file-details">
          {htmlFilesData
            .filter((fileData) => fileData.fileName === selectedFile)
            .map((fileData, fileIndex) => {
              // Entferne Duplikate in der Kursliste
              const uniqueTimetable = removeDuplicateCourses(fileData.timetable);

              return (
                <div key={fileIndex} className="file-block">
                  <p><strong>Ausgewählte Datei: {fileData.fileName}</strong></p>

                  {uniqueTimetable.length > 0 && (
                    <div className="course-list">
                      <h3>Kurse und Dozenten (für {fileData.fileName}):</h3>
                      <ul>
                        {uniqueTimetable.map((course, index) => (
                          <li key={index}>
                            <label>
                              <input
                                type="checkbox"
                                checked={selectedCourses[fileData.fileName]?.includes(course.Course) || false}
                                onChange={() => onCourseSelect(fileData.fileName, course.Course)}
                              />
                              <strong>{course.Course}</strong> - {course.Instructor}
                            </label>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      )}

      <button onClick={onFileUpload}>Hochladen</button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default FileUpload;
