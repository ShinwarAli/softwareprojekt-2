import React from 'react';
import './Auswahl.css';

const Header = () => (
    <main id='mainAuswahl'>
     <p>Hallo</p>
    </main>
  
);

function redirectToTimetable() {
  window.location.href = 'auswahl.html';
}

export default Header;