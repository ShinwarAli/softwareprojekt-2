import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Regester.css';

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    vorname: '',
    email: '',
    passwort: '',
    passwortwiederholen: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Check if passwords match
    if (formData.passwort !== formData.passwortwiederholen) {
      alert('Passwörter stimmen nicht überein.');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/students', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          vorname: formData.vorname,
          email: formData.email,
          passwort: formData.passwort
        })
      });

      const result = await response.json();
      if (response.ok) {
        console.log('User created:', result);
        alert('Registrierung erfolgreich!');
        // Reset form
        setFormData({
          name: '',
          vorname: '',
          email: '',
          passwort: '',
          passwortwiederholen: ''
        });
        // Navigate to login page
        navigate('/');
      } else {
        alert('Fehler bei der Registrierung: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Fehler bei der Registrierung.');
    }
  };

  return (
    <div className="register">
      <main className="register-main">
        <div className="content-container">
          <div className="ueberschrift">
            <h1>STUDYPLANERMANAGER</h1>
          </div>
          <div className="unterschrift">
            <p>BITTE GEBEN SIE IHRE DATEN EIN</p>
          </div>
          <form className="input-container" onSubmit={handleSubmit}>
            <label htmlFor="name" className="nameOben">Name:</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Geben Sie Ihren Namen ein" required />

            <label htmlFor="vorname" className="vornameOben">Vorname:</label>
            <input type="text" id="vorname" name="vorname" value={formData.vorname} onChange={handleChange} placeholder="Geben Sie Ihren Vornamen ein" required />

            <label htmlFor="email" className="emailOben">Email:</label>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} placeholder="Geben Sie Ihre Email ein" required />

            <label htmlFor="passwort" className="passwortlOben">Passwort:</label>
            <input type="password" id="passwort" name="passwort" value={formData.passwort} onChange={handleChange} placeholder="Geben Sie Ihr Passwort ein" required />

            <label htmlFor="passwortwiederholen" className="passworwiederholentlOben">Passwort wiederholen:</label>
            <input type="password" id="passwortwiederholen" name="passwortwiederholen" value={formData.passwortwiederholen} onChange={handleChange} placeholder="Geben Sie Ihr Passwort nochmal ein" required />

            <div className="button-container">
              <button type="submit" className="register-button">Registrieren</button>
            </div>
          </form>
        </div>
        <div className="image-container">
          <img src={`${process.env.PUBLIC_URL}/regester2.png`} alt="Bildbeschreibung" className="register-image" />
        </div>
      </main>
    </div>
  );
};

export default Register;
